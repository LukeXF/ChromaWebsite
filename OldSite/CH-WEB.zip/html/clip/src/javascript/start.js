(function (window) {
  "use strict";
