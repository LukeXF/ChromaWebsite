<?php include "navbar.php"; ?>



<body style="margin: 20px;">
<iframe src="http://store.chromahills.net" style="position:fixed; top:20px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0;"></iframe>
</body>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>