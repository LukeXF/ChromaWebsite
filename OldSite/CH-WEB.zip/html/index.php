<?php include "navbar.php"; ?>
<?php include "headerwrap.php"; ?>

	<section id="works"></section>
	<div class="container">
		<div class="row centered mt mb">
			<h1 class="welcome">Welcome to the Chroma Hills network server page.</h1>
			<h3 class="welcome2">If you wish to go to the resource pack site then <a href="http://chromahills.com">click here</a>.
			<!--<a href="#" id="copy-description">Click here to copy the IP</a>
			<p id="description">chromatesttext</p>-->
			<div class"row">
				<div class="col-lg-12 col-md-12 col-sm-12">


<div id="demo">
	<div class="container">
		<div class="row">
			<div class="span12">

			<div id="owl-demo" class="owl-carousel">
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(1).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(2).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(3).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(4).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(5).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(6).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(7).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(8).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(9).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(10).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(11).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(12).jpg" class="server" alt="Server" width="304">
				</div>
				<div class="item">
					<img border="0" src="/assets/img/server/server%20(13).jpg" class="server" alt="Server" width="304">
				</div>
			</div>
				<div class="customNavigation">
					<a class="btn-light prev">Previous</a>
					<a class="btn-light next">Next</a>
					<a class="btn-light play">Autoplay</a>
					<a class="btn-light stop">Stop</a>
				</div>
			</div>
		</div>
	</div>
</div>




			</div>
		</div>
	</div>
			<div class"row">
				<div class="col-lg-4 col-md-4 col-sm-4">
					<div class="col-lg-12 col-md-12 col-sm-12 ch-col left">
						<h1 class="ch-header">Voting</h1>
						<p>
							Vote for our server today and recieve awesome rewards!
						</p>
						<a href="http://www.minecraftservers.org/server/122452">
						<img border="0" align="middle" src="/assets/img/vote1.png"  alt="Pulpit rock" width="100">
						</a><a href="http://www.planetminecraft.com/server/chroma-hills-factions---100k-custom-biome-world---custom-dungeons---custom-loot-more/vote/">
						<img border="0" align="middle" src="/assets/img/vote2.png"  alt="Pulpit rock" width="100"><br>
						</a><a href="http://minecraft-mp.com/server-s38321">
						<img border="0" align="middle" src="/assets/img/vote3.png"  alt="Pulpit rock" width="100">
						</a><a href="https://minestatus.net/106316-chroma-hills">
						<img border="0" align="middle" src="/assets/img/vote4.png"  alt="Pulpit rock" width="100">
						</a>
					</div>


					<div class="col-lg-12 col-md-12 col-sm-12 ch-col left">
						<a class="twitter-timeline" href="https://twitter.com/ChromaHills" data-widget-id="467458650508763136">Tweets by @ChromaHills</a>
						<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
					</div>

				</div>
			</div>

			<div class="col-lg-8 col-md-8 col-sm-8 ch-col">
				<h1 class="ch-header">What is Chroma hills?</h1>
				<p class="news">

				<br>Based on the resource pack using the popular Factions game mode with an awesome helping Of RPGness!
				<br>A very unique adventure themed spawn, rich In fantastic detail and design!
				<br>
				<br>Based on the Chroma Hills Resource Pack, we bring Chroma Hills to servers!
				<br><br>
				<a href="/assets/img/lightbox/FactionsInfo.png" data-lightbox="image-2" data-title="Factions Server">
					<img border="0" src="/assets/img/serverslabs/factions.png" alt="Server" width="700">
				</a>
				<br><br>
				<a href="/assets/img/lightbox/Kitpvpinfo.png" data-lightbox="image-2" data-title="KitPvP Server">
					<img border="0" src="/assets/img/serverslabs/kitpvp.png" width="700">
				</a>
				<br><br>
				<a href="/assets/img/lightbox/CreativeInfo.png" data-lightbox="image-2" data-title="Creative Server">
					<img border="0" src="/assets/img/serverslabs/creative.png" width="700">
				</a>
				</p>
			</div><br>
			<div class="col-lg-12 col-md-12 col-sm-12 ch-col">
				<div class="col-lg-5 col-md-5 col-sm-5">
						<h1 class="ch-header">So what are you waiting for?</h1>
						<p class="news">
							Join us today and get started on a large array of games we have to offer, get yourself known on the forums.
							Become part of the community today! Donate, vote or player. Eitherway, we look forward to meeting you!
						</p>
				</div>
				<div class="col-lg-7 col-md-7 col-sm-7">
						<iframe width="560" height="315" src="//www.youtube.com/embed/I4-bYWDY52s" frameborder="0" allowfullscreen></iframe>
				</div>
			</div>

		</div><!--row -->
	</div><!--/container -->
<?php include "footer.php"; ?>