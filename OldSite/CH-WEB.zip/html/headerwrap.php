<div id="headerwrap">
	    <div class="container">
			<div class="row">
				<div class="col-lg-12">
					<img align="middle" border="0" src="/assets/img/CHLogo.png" alt="Pulpit rock" height="250">

					<div id="buttons">
						<A class="whitenormal" href="http://www.chromahills.com/">TEXTURE PACK HOME</a>&nbsp;|&nbsp;
						<A class="whitenormal" href="http://www.chromahills.com/forum/">FORUM</a>&nbsp;|&nbsp;
						<A class="whitenormal" href="https://twitter.com/chromahills">TWITTER</a>&nbsp;|&nbsp;
						<A class="whitenormal" href="/assets/img/lightbox/Kitpvpinfo.jpg" data-lightbox="image-1" data-title="The KitPvP Server">KITPVP</a>&nbsp;|&nbsp;
						<A class="whitenormal" href="/assets/img/lightbox/FactionsInfo.png" data-lightbox="image-1" data-title="The Factions Server">FACTIONS</a>&nbsp;|&nbsp;
						<A class="whitenormal" href="http://www.chromahills.com/forum/viewtopic.php?f=5&amp;t=3">CREATIVE</a>
					</div>

				</div>
			</div><!--/row -->
	    </div> <!-- /container -->
	</div><!--/headerwrap -->